<div class="modal fade" id="modal-employee-profile">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Employee Profile</h4>
			</div>
			<div class="modal-body">
		<!-- form -->
				<form class="form-horizontal" role="form">
				  <div class="form-group">
				    <label class="control-label col-sm-3">First Name:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control fN" disabled>
				    </div>
				  </div>

				  <div class="form-group">
				    <label class="control-label col-sm-3">Middle Name:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control mN" disabled>
				    </div>
				  </div>

				  <div class="form-group">
				    <label class="control-label col-sm-3">Last Name:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control lN" disabled>
				    </div>
				  </div>

				  <div class="form-group">
				    <label class="control-label col-sm-3">Position:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control position" disabled>
				    </div>
				  </div>

				   <div class="form-group">
				    <label class="control-label col-sm-3">Office:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control office" disabled>
				    </div>
				  </div>

		<!-- 		   <div class="form-group">
				    <label class="control-label col-sm-3">Account Type:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control type" disabled>
				    </div>
				  </div>
 -->
				  <!-- <div class="form-group">
				    <label class="control-label col-sm-3">Worked Here:</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control wh" disabled>
				    </div>
				  </div> -->

				</form>
		<!-- form -->
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">OK
				<span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
				</button>
			</div>
		</div>
	</div>
</div>

				
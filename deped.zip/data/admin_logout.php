<?php 
require_once('../class/Login.php');
$login->admin_logout();
$login->Disconnect();
<?php 
require_once('../class/Login.php');
$login->admin_session();
$login->Disconnect();
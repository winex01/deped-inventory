<?php 
require_once('../class/Login.php');
$login->user_session();
$login->Disconnect();
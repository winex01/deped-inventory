<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:5px;">
    <div class="container-fluid">
     <div class="banner">
                    <img src="../img/logo.png" width="200" height="90" style="position:absolute;margin-top:-20px;">
<div style="color:red;margin-left:250px;margin-bottom:50px;margin-top:20px;font-size:30px;font-family:Bodoni MT Black;">Inventory System</div>

               </div> 
     

     </div>
    </nav>
<?php 
interface iOffice{
	public function get_offices();
}